
#include "ItemWidget.h"

ItemWidget::ItemWidget(QWidget* parent) : QWidget(parent) {
}
